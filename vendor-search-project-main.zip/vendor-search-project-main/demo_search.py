import pandas as pd
import numpy as np
import spacy
from tqdm import tqdm
import matplotlib.pyplot as plt
from gensim.models.fasttext import FastText
from rank_bm25 import BM25Okapi
import nmslib
import time
from ftfy import fix_text
import pickle

search_term = 'revenue'.lower()
print(f'searching for: {search_term}')

t0 = time.time()

train = False

if train:

    print('Loading Pickle files and data files')

    df = pd.read_csv('Trainingdata_Fasttextmodel.csv')
    df['text'] =  df['fields_nostop']+ ' ' + df['Field Category']+ ' ' + df['Speciality']+ ' ' + df['Sub Category']+ ' ' + df['tags']
    df.shape
    # pd.to_pickle(df, "data.pkl")


    df.head(2)


    nlp = spacy.load("en_core_web_sm")
    tok_text=[] # for our tokenised corpus
    text = df.text.str.lower().values
    text = [fix_text(str(i)) for i in text]
    print('Tokenising using SpaCy')
    for doc in tqdm(nlp.pipe(text, batch_size=2, disable=["tagger", "parser", "ner", 'lemmatizer'])):
        tok = [t.text for t in doc if (t.is_ascii and not t.is_punct and not t.is_space)]
        tok_text.append(tok)


    ft_model = FastText(
        sg=1, # use skip-gram: usually gives better results
        size=100, # embedding dimension (default)
        window=10, # window size: 10 tokens before and 10 tokens after to get wider context
        min_count=5, # only consider tokens with at least n occurrences in the corpus
        negative=15, # negative subsampling: bigger than default to sample negative examples more
        min_n=2, # min character n-gram
        max_n=5 # max character n-gram
    )

    print('Build vocabulary')

    ft_model.build_vocab(tok_text)

    print('Train')

    ft_model.train(
        tok_text,
        epochs=6,
        total_examples=ft_model.corpus_count,
        total_words=ft_model.corpus_total_words)

    ft_model.save('_fasttext.model')

    ft_model = FastText.load('_fasttext.model')
    # filename = 'ft_model.sav'
    # pickle.dump(ft_model, open(filename, 'wb'))
    #
    #
    # with plt.xkcd():
    #   pd.DataFrame(ft_model.wv.most_similar(search_term, topn=20, restrict_vocab=10000),columns=['Word','Score']).plot.barh(x='Word',figsize=(6,6),color=(0.3,0.7,0.7))


    # #%%
    print('BM25')

    bm25 = BM25Okapi(tok_text)
    weighted_doc_vects = []

    for i,doc in tqdm(enumerate(tok_text)):
      doc_vector = []
      for word in doc:
        vector = ft_model.wv[word]
        weight = (bm25.idf[word] * ((bm25.k1 + 1.0)*bm25.doc_freqs[i][word])) / (bm25.k1 * (1.0 - bm25.b + bm25.b *(bm25.doc_len[i]/bm25.avgdl))+bm25.doc_freqs[i][word])
        weighted_vector = vector * weight
        doc_vector.append(weighted_vector)
      doc_vector_mean = np.mean(doc_vector,axis=0)
      weighted_doc_vects.append(doc_vector_mean)

    #%%

    pickle.dump( weighted_doc_vects, open( "weighted_doc_vects.p", "wb" ) )

    #%%

    #%% md

    print('Most similar:')
    for index2, word2 in ft_model.wv.most_similar(search_term, topn=20, restrict_vocab=10000):
        print(f'{index2}\t{word2}')

print('Load model and data')

filename= 'ft_model.sav'
ft_model = pickle.load(open(filename, 'rb'))
df = pd.read_pickle("data.pkl")

print('Load document vectors, build index and search')

#%%

with open( "weighted_doc_vects.p", "rb" ) as f:
  weighted_doc_vects = pickle.load(f)
# create a random matrix to index
data = np.vstack(weighted_doc_vects)

# initialize a new index, using a HNSW index on Cosine Similarity - can take a couple of mins
index = nmslib.init(method='hnsw', space='cosinesimil')
index.addDataPointBatch(data)
index.createIndex({'post': 2}, print_progress=True)

#%%

# querying the index:
# input = 'phone number'.lower().split()
input = search_term.split()


query = [ft_model.wv[vec] for vec in input]
query = np.mean(query,axis=0)
df_new=set()
# t0 = time.time()
ids, distances = index.knnQuery(query, k=20)
t1 = time.time()
print(f'Searched {df.shape[0]} records in {round(t1-t0,4) } seconds')
for i,j in zip(ids,distances):
#     print(round(j,2))
    df_new.add(f'{df.API.values[i]}: {df.Label.values[i]} ({df.Name.values[i]})')
    # df_new.add(df.API.values[i])

for index1, item in enumerate(df_new):
    print(f'# {index1+1}\t{item}')

#%%


