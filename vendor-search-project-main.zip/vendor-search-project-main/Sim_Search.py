# -*- coding: utf-8 -*-
"""
Created on Thu Mar 18 14:02:31 2021

@author: dalle
"""
import nmslib
import pandas as pd
import numpy as np
import pickle
import time

def Remove(duplicate):
    final_list = []
    for api in duplicate:
        if api not in final_list:
            final_list.append(api)
    return final_list

def getList(dict):
    return dict.keys()

filename= 'ft_model.sav'
ft_model = pickle.load(open(filename, 'rb'))
df = pd.read_pickle("data.pkl")
df['api_lower']= df['API'].str.lower()
df['field_lower'] = df['Label'].str.lower()
df['Field Category']= df['Field Category'].str.lower()


input = 'zoom'.lower().split()
search_string= ' '.join(input)

#load index, run model and return top 20 ids,distances closest to input
new_index = nmslib.init()
new_index.loadIndex("Indexdata.bin", load_data=True)

query = [ft_model[vec] for vec in input]
query = np.mean(query,axis=0)

t0 = time.time()
ids, distances = new_index.knnQuery(query, k=20)
t1 = time.time()

#scan each field to check if exact search_string is contained in field, add to df_new at beginning of list

df_new= df[df['field_lower'].str.contains(search_string, na=False)]['API']
df_label= df[df['field_lower'].str.contains(search_string, na=False)]['Label']

df_new= df_new.to_list()
df_label= df_label.to_list()

df_new = [i + ' ' + j for i, j in zip(df_new, df_label)]

#return fields that have have ids that are .05 or closer, add to existing df_new 
print(f'Searched {df.shape[0]} records in {round(t1-t0,4) } seconds \n')
for i,j in zip(ids,distances):
    if j < .05:
        df_new.append(f'{df.API.values[i]} {df.Label.values[i]}')    
#{df.Label.values[i]}


#Check if search_string is a part of an api, save as list
api_list= df[df['api_lower'].str.contains(search_string, na=False)]['API']
api_list= api_list.to_list()
 
#Check if search_string is a part of field category and how many times, save as list
fieldcat_list= df[df['Field Category'].str.contains(search_string, na=False)]['API']
fieldcat_list= fieldcat_list.to_list()


#if api list has contents, overwrite df_new and only display the api that corresponds to the search
#if fieldcat_list has contents, overwrite df_new and display vendors in the order of the count of field_cat  
pairs = {}
if api_list:
    df_new = api_list
if fieldcat_list:
    for i in fieldcat_list:
        if i not in pairs:
             pairs[i] = 0
        pairs[i] = pairs[i] + 1
        pairs= dict(sorted(pairs.items(), key=lambda item: item[1], reverse=True))   
        fieldcat_list= getList(pairs)
        df_new = fieldcat_list

#Remove duplicates    
df_new= Remove(df_new)

print('SEARCH TERM')
print(search_string)
print(distances)
print('NUMBER OF FIELD CATEGORIES')
print(pairs)

print('SEARCH RESULT')
print(df_new)