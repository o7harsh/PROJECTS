# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 13:53:02 2021

@author: dalle
"""
from sklearn.model_selection import RandomizedSearchCV
from sklearn.neural_network  import MLPClassifier
from imblearn.over_sampling import SMOTE
import pickle
from nltk.corpus import wordnet
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd
import re
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn import metrics
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from imblearn.under_sampling import RandomUnderSampler
from nltk import ngrams

#Load training data with field categories assigned
trainingdata= pd.read_csv('trainingdata.csv')

result= trainingdata
result= result.astype(str)

#Define lemmatizer
lemmatizer = nltk.stem.WordNetLemmatizer()
    
#Create field column in lowercase with no stop words
result["fields_lower"] = result["Label"].apply(lambda x: re.sub('[^a-zA-Z]',' ',x))
stop_words = set(stopwords.words("english"))
result["fields_nostop"] = result["fields_lower"].apply(lambda words: ' '.join(word.lower() for word in words.split() if word not in stop_words))

#Create "top words" set to be used as a filter in creating tag column
text_wc = " ".join(item for item in result["fields_nostop"])
bigrams = ngrams(text_wc.split(), 2)
bigram_fd = nltk.FreqDist(bigrams)
ringlead_popularwords= bigram_fd.most_common()[:500]
ringlead_popularwords= [item[0] for item in ringlead_popularwords]

#Save top words
top_words_path = 'top_field_words.pkl'
with open(top_words_path, 'wb') as fw:
     pickle.dump(ringlead_popularwords, fw)

#Create text column with group and label, tf-idf model features will be created with these columns
#Consider adding more features in the future if new columns are created
label= result['fields_nostop']
group= result['Group']
text_column = group +' '+ label

def nltk_tag_to_wordnet_tag(nltk_tag):
    if nltk_tag.startswith('J'):
        return wordnet.ADJ
    elif nltk_tag.startswith('V'):
        return wordnet.VERB
    elif nltk_tag.startswith('N'):
        return wordnet.NOUN
    elif nltk_tag.startswith('R'):
        return wordnet.ADV
    else:
        return None

def lemmatize_sentence(sentence):
    #tokenize the sentence and find the POS tag for each token
    nltk_tagged = nltk.pos_tag(nltk.word_tokenize(sentence))
    #tuple of (token, wordnet_tag)
    wordnet_tagged = map(lambda x: (x[0], nltk_tag_to_wordnet_tag(x[1])), nltk_tagged)
    lemmatized_sentence = []
    for word, tag in wordnet_tagged:
        if tag is None:
            #if there is no available tag, append the token as is
            lemmatized_sentence.append(word)
        else:
            #else use the tag to lemmatize the token
            lemmatized_sentence.append(lemmatizer.lemmatize(word, tag))
    return " ".join(lemmatized_sentence)

def remove_noise(text, stop_words=stop_words):
    tokens = word_tokenize(text)
    cleaned_tokens = []
    for token in tokens:
        token = re.sub('[^A-Za-z0-9]+', '', token)
        token = re.sub('[^a-zA-Z]+', '', token)
        token = lemmatize_sentence(token)
        if len(token) > 1 and token.lower() not in stop_words:
            cleaned_tokens.append(token.lower())
    return cleaned_tokens

#Form tfidf
tfidf_vectorizer = TfidfVectorizer(min_df=.003, tokenizer=remove_noise, ngram_range = (1,3))
tfidf_transformer= tfidf_vectorizer.fit_transform(text_column)
tfidf_pd_df= pd.DataFrame(tfidf_transformer.toarray(), columns=tfidf_vectorizer.get_feature_names(), index = result.index)

#Overwrite tfidf vocabulary
feature_path = 'feature.pkl'
with open(feature_path, 'wb') as fw:
    pickle.dump(tfidf_vectorizer.vocabulary_, fw)

     
#Split to train/test
tfidf_pd_df["category_dep_column"] = result["Field Category"]
X = tfidf_pd_df.drop(['category_dep_column'], axis=1)  
y = tfidf_pd_df.category_dep_column
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33)

#oversample and undersample
strategy = {'Company Communications':500, 'Company Intent':500, "Personal Education":500, "Hospitals":500, "Company Basic Information":500, "Personal Communications":500, "Company Technographics":500, "Company Social Data":500, "Personal Bio":500, "Company Firmographics":500, "Company Financials":500, "Personal Occupation":500, "Company Geographics":500, "Other":500, "Personal Social Data":500, "Personal Geographics":500, "Company Digital Information":500}
oversample = SMOTE(sampling_strategy=strategy)
strategyu= {"Institutions":500}
undersample = RandomUnderSampler(sampling_strategy=strategyu)

X_train, y_train = oversample.fit_resample(X_train, y_train)
X_train, y_train = undersample.fit_resample(X_train, y_train)


#Run and pickle model
np.random.seed(42)
mlp = MLPClassifier()
# set the hyper parameter grid
hyper_parameter_space = {
    'hidden_layer_sizes': [(15,15,15), (13,12,13), (13,15), (10, 10)], # (5,5,5) means 3 layers, each having 5 nodes
    'activation': ['tanh'],
    'learning_rate': ['adaptive'], # adaptive learning rate updates when needed, in relationship with epochs
}
# set up the structure of the random grid search using mlp model; n_iter denotes how many models should be tried by randomly selecting hyper-parameters
mlp_gr_src = RandomizedSearchCV(mlp, hyper_parameter_space, n_iter = 5, cv = 10, random_state = 123, scoring = 'accuracy') # cv = cross-validation
# fit the ml (with random grid search) on the train data
mlp_gr_src.fit(X=X_train, y=y_train)
pred = mlp_gr_src.predict(X=X_train)

print(mlp_gr_src.best_score_) 
print(mlp_gr_src.best_params_) 
print(mlp_gr_src.best_estimator_)

y_pred_train_class = pred
print(metrics.classification_report(y_train, y_pred_train_class))

print("Confusion Matrix:")
conf_mat_train = confusion_matrix(y_true=y_train, y_pred=y_pred_train_class)
print(conf_mat_train)
print("Train Accuracy:", metrics.accuracy_score(y_train, y_pred_train_class))

test_pred= mlp_gr_src.predict(X=X_test)
print("Test Accuracy:", metrics.accuracy_score(y_test, test_pred))

#Pickle Model
filename = 'mlp_model_ringlead.sav'
pickle.dump(mlp_gr_src, open(filename, 'wb'))

