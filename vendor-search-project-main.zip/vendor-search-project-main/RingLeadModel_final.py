# -*- coding: utf-8 -*-
"""
Created on Fri Feb 12 11:45:46 2021

@author: dalle
"""

import pickle
from nltk.corpus import wordnet
from nltk.stem import WordNetLemmatizer 
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd
import re
from nltk.tokenize import word_tokenize
import numpy as np
from nltk import ngrams

result= pd.read_csv('newdata.csv')
result=result.astype(str)

#load top words
filename= 'top_field_words.pkl'
ringlead_popularwords = pickle.load(open(filename, "rb"))

#load tfidf features and create vectorizer
feature_path = 'feature.pkl'
tfidf_vectorizer = TfidfVectorizer(decode_error="replace", vocabulary=pickle.load(open(feature_path, "rb")))

#Load mlp model
filename= 'mlp_model_ringlead.sav'
category_model = pickle.load(open(filename, 'rb'))

lemmatizer = nltk.stem.WordNetLemmatizer()

#Force Field Categories
   
result["fields_nostop"] = result["Label"].apply(lambda x: re.sub('[^a-zA-Z]',' ',x))
result["fields_nostop"] = result["fields_nostop"].str.lower()
stopwords = nltk.corpus.stopwords.words('english')
newStopWords = ['api','crunchbase','zoominfo','aberdeen','insideview','bombora','agile']
stopwords.extend(newStopWords)
result["fields_nostop"] = result["fields_nostop"].apply(lambda words: ' '.join(word.lower() for word in words.split() if word not in stopwords))

companycomsyn= "toll free number|company phone|company email|hq phone"
companyinfosyn= "company mission|company ein|company ticker|company rankings|company name|company"
techsyn= 'tech|technology|technologies|company technologies|company technology|software|hardware|surveillance security system|phone system'
companywebsyn= 'company website|company domain|company url|urls'
companyfinsyn= 'credit code|number investments|expense|fortune ranking|fortune rank|revenue|company sales|company fortune|company sales growth|acquisition|ipo|company finance|company revenue'
companysocialsyn= "company yelp|company facebook|company linkedin|company twitter|company social|company google"
hospitalsyn= "healthcare|hospital|hosptial"
companyaddresssyn= "zip code|area code|company area code|latitude|company geo|company hq timezone|company region|company address|hq address|company hq address|company city|company country|company location|company hq location|company hq country|company street name|company postal code"
companyfirmsyn= "franchise|annual budget|subindustry|employees number|number employees|price level|company sub|company alexa|company subindustry|company sub industry|company ownership|company family|square foot|company sector|company industries|company subindustry|company employees|sic|naics|company industry|employee size|nace|employee count|employee range"
personphonesyn= "phones number|person phone|personal phone|direct dial|person mobile|person work phone|person email"
intentsyn= "company signal|score|company intent|intent"
personbiosyn= "person|user|first name|last name|relationships|person id|pipl id|person name|gender|person first name|interest|person last name|person analytics|person bio"
personedusyn= "person education|person degree|contact education|education"
personjobsyn= "salary|job|jobs|person job|person work|person past work|person job|person previous employer|person previous work|person skill|person experience|person employer"
personsocialsyn= "personal flickr|personal foursquare|personal googleplus|personal gravitar|personal plancast|personal slideshare|personal blog|personal angellist|personal instagram url|personal aboutme url|personal amazon url|personal angelist url|personal klout url|personal myspace url|personal quora url|personal vimeo url|personal xing url|contact social|personal github|personal youtube|personal person twitter|person facebook|person linked|person social|personal twitter|personal facebook|personal linked|personal social"
persongeo= "addresses|person location|person address|home address"
institutionsyn= "institution|school|instructional|teachers|rpm rank|number librarians|number guidance counselors|district feature"
othersyn= "user territory level|user defined field|code"
 
result['Field Category'] = pd.np.where(result.fields_nostop.str.contains(companycomsyn), "Company Communications",
                                     pd.np.where(result.fields_nostop.str.contains(intentsyn), "Company Intent",
                                     pd.np.where(result.fields_nostop.str.contains(personedusyn), "Personal Education",
                                     pd.np.where(result.fields_nostop.str.contains(hospitalsyn), "Hospitals",
                                     pd.np.where(result.fields_nostop.str.contains(institutionsyn), "Institutions", 
                                     pd.np.where(result.fields_nostop.str.contains(personphonesyn), "Personal Communications",
                                     pd.np.where(result.fields_nostop.str.contains(companysocialsyn), "Company Social Data",
                                     pd.np.where(result.fields_nostop.str.contains(companyfirmsyn), "Company Firmographics", 
                                     pd.np.where(result.fields_nostop.str.contains(companyfinsyn), "Company Financials",
                                     pd.np.where(result.fields_nostop.str.contains(personjobsyn), "Personal Occupation",
                                     pd.np.where(result.fields_nostop.str.contains(persongeo), "Personal Geographics",
                                     pd.np.where(result.fields_nostop.str.contains(companyaddresssyn), "Company Geographics",
                                     pd.np.where(result.fields_nostop.str.contains(personsocialsyn), "Personal Social Data",
                                     pd.np.where(result.fields_nostop.str.contains(techsyn), "Company Technographics",            
                                     pd.np.where(result.fields_nostop.str.contains(companywebsyn), "Company Digital Information", 
                                     pd.np.where(result.fields_nostop.str.contains(companyinfosyn), "Company Basic Information", 
                                     pd.np.where(result.fields_nostop.str.contains(personbiosyn), "Personal Bio", 
                                     pd.np.where(result.fields_nostop.str.contains(othersyn), "Other", "None"))))))))))))))))))


#Run model
def nltk_tag_to_wordnet_tag(nltk_tag):
    if nltk_tag.startswith('J'):
        return wordnet.ADJ
    elif nltk_tag.startswith('V'):
        return wordnet.VERB
    elif nltk_tag.startswith('N'):
        return wordnet.NOUN
    elif nltk_tag.startswith('R'):
        return wordnet.ADV
    else:
        return None

def lemmatize_sentence(sentence):
    #tokenize the sentence and find the POS tag for each token
    nltk_tagged = nltk.pos_tag(nltk.word_tokenize(sentence))
    #tuple of (token, wordnet_tag)
    wordnet_tagged = map(lambda x: (x[0], nltk_tag_to_wordnet_tag(x[1])), nltk_tagged)
    lemmatized_sentence = []
    for word, tag in wordnet_tagged:
        if tag is None:
            #if there is no available tag, append the token as is
            lemmatized_sentence.append(word)
        else:
            #else use the tag to lemmatize the token
            lemmatized_sentence.append(lemmatizer.lemmatize(word, tag))
    return " ".join(lemmatized_sentence)

def remove_noise(text, stop_words=stopwords):
    tokens = word_tokenize(text)
    cleaned_tokens = []
    for token in tokens:
        token = re.sub('[^A-Za-z0-9]+', '', token)
        token= token.str.lower()
        token = re.sub('[^a-zA-Z]+', '', token)
        token = lemmatize_sentence(token)
        if len(token) > 1 and token.lower() not in stop_words:
            cleaned_tokens.append(token.lower())
    return cleaned_tokens



blankfieldcat= result[result['Field Category'] == 'None']
label= blankfieldcat['fields_nostop']
group= blankfieldcat['Group']
text_column = group +' '+ label
result= result[result['Field Category'] != 'None']
tfidf_transformer= tfidf_vectorizer.fit_transform(text_column)
tfidf_pd_df= pd.DataFrame(tfidf_transformer.toarray(), columns=tfidf_vectorizer.get_feature_names(), index = blankfieldcat.index)
pred = category_model.predict(X=tfidf_pd_df)
blankfieldcat['Field Category']=pred
frames= [result, blankfieldcat]
result= pd.concat(frames)

communicationsyn="Personal Communications|Company Communications"
Socialdatasyn = "Personal Social Data|Company Social Data"
Geographicssyn = "Personal Geographics|Company Geographics"
Financialssyn = "Personal Financials|Company Financials"
Industrysyn = "Hospitals|Institutions"
PersonnelInformationsyn = "Personal Education|Personal Bio|Personal Occupation"
OrganizationInformation = "Company Intent|Company Basic Information|Company Digital Information|Company Technographics|Company Firmographics"

result['Speciality']=  pd.np.where(result['Field Category'].str.contains(communicationsyn),'Communications', 
                                   pd.np.where(result['Field Category'].str.contains(Socialdatasyn),'Social Data',
                                   pd.np.where(result['Field Category'].str.contains(Geographicssyn),'Geographics',
                                   pd.np.where(result['Field Category'].str.contains(Financialssyn),'Financials',
                                   pd.np.where(result['Field Category'].str.contains(Industrysyn),'Industries',
                                   pd.np.where(result['Field Category'].str.contains(PersonnelInformationsyn),'Personal Information',
                                   pd.np.where(result['Field Category'].str.contains(OrganizationInformation),'Company Information',
                                               "Other")))))))
emailsyn = "email"
phonesyn= "phone|direct dial|toll free number|mobile|extension"
fintransacsyn= "acquisition|ipo"
revenuesyn= "revenue"
industrysyn= "industry|naics|nace|sic|industries|subindustry|sector"
softwaresyn= "software|enterprise"
hardwaresyn= "hardware"
addresssyn= "address"
websitesyn= "url"
socialmedia= "company yelp|company facebook|company linkedin|company twitter|company social|company google|personal flickr|personal foursquare|personal googleplus|personal gravitar|personal plancast|personal slideshare|personal blog|personal angellist|personal instagram url|personal aboutme url|personal amazon url|personal angelist url|personal klout url|personal myspace url|personal quora url|personal vimeo url|personal xing url|contact social|personal github|personal youtube|personal person twitter|person facebook|person linked|person social|personal twitter|personal facebook|personal linked|personal social"


result['Sub Category']= pd.np.where(result.fields_nostop.str.contains(emailsyn), 'Email',
                                    pd.np.where(result.fields_nostop.str.contains(phonesyn), 'Phone',
                                    pd.np.where(result.fields_nostop.str.contains(fintransacsyn), 'Financial Transactions',
                                    pd.np.where(result.fields_nostop.str.contains(revenuesyn), 'Revenue',
                                    pd.np.where(result.fields_nostop.str.contains(industrysyn), 'Industry',
                                    pd.np.where(result.fields_nostop.str.contains(softwaresyn), 'Software',
                                    pd.np.where(result.fields_nostop.str.contains(hardwaresyn), 'Hardware',
                                    pd.np.where(result.fields_nostop.str.contains(addresssyn), 'Street Address',
                                    pd.np.where(result.fields_nostop.str.contains(websitesyn), 'Web Page URL',
                                    pd.np.where(result.fields_nostop.str.contains(socialmedia), 'Social Media',
                                      " "))))))))))

result['tags'] = result['fields_nostop'].apply(lambda x: ' '.join(np.array(x.split(' '))[np.in1d(x.split(' '),ringlead_popularwords)]))


              
result.to_csv('updatedfields.csv')


    
       
                                       
